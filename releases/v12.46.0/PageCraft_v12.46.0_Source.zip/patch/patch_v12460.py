"""PageCraft v12.46.0 — 서명 버전 + 1024 화면 잘림.
기준: v12.45.0 Lite.
 1) 하단 서명(#rv-app-signature)이 v12.44.0에 멈춰 있던 것 → v12.46.0.
    앞으로 안 어긋나게 시작할 때 BUILD_VERSION에서 서명 글자를 채움(버전 문자열 한 곳)
 2) 1024 폭 잘림 (pc-ui-css 안 기존 @media(max-width:1100px) 구역을 직접 고침, 새 블록·!important 없음)
    · 상단 버튼줄: ≤1100 오른쪽 끝 [인쇄·PDF] 테두리 잘림 → 버튼 좌우 여백 12→8px
      1101~1215 폭에서 버튼줄이 최대 99px 화면 밖(기존 문제) → ≤1240에서 저장 상태 글씨·부제 숨김(≤1100과 같은 처리)
    · 상세 설정 [페이지에 적용]·[문서 전체 적용]: 오른쪽 칸 밖으로 넘쳐 잘림 → 글꼴 고르기 아래 줄로 내림
    · 상세 설정 탭 작은 글씨(수치·색·위치·잠금 등) 칸 넘침 → ≤1350 탭 좌우 여백 0·작은 글씨 10px, ≤1100 9px
Usage: python3 -I patch_v12460.py <PageCraft_v12.45.0_Lite.html> <out.html>"""
import sys
src,out=sys.argv[1],sys.argv[2]
html=open(src,encoding='utf-8').read()
def R(old,new,n=1):
    global html
    c=html.count(old);assert c==n,f'expected {n} got {c}: {old[:80]!r}'
    html=html.replace(old,new)
OLDV="PageCraft v12.45.0 · 코드 정리(CSS·단축키 한 곳)"
NEWV="PageCraft v12.46.0 · 서명 버전·1024 화면 잘림"
assert f"BUILD_VERSION='{OLDV}'" in html,'needs v12.45.0'

# 1) 서명
R(f"const BUILD_VERSION='{OLDV}';",
  f"const BUILD_VERSION='{NEWV}';\n"
  "{const sig=document.getElementById('rv-app-signature');if(sig)sig.textContent='Jungmin Jo · '+BUILD_VERSION.split(' · ')[0];}")
R(f'<title>페이지공방 v12.45.0 · 코드 정리(CSS·단축키 한 곳)</title>','<title>페이지공방 v12.46.0 · 서명 버전·1024 화면 잘림</title>')
R('Jungmin Jo · PageCraft v12.44.0</span>','Jungmin Jo · PageCraft v12.46.0</span>')

# 2) 1024 잘림 — pc-ui-css 안 기존 구역
a=html.find('<style id="pc-ui-css">');b=html.find('</style>',a);assert a>0
css=html[a:b]
def C(old,new):
    global css
    assert css.count(old)==1,old[:80];css=css.replace(old,new)
C("@media(max-width:1100px){.brand{gap:8px}.brand small{display:none}.header-actions{gap:4px}.save-status{display:none}",
  "@media(max-width:1240px){.brand small{display:none}.header-actions{gap:4px}.save-status{display:none}}\n"
  "@media(max-width:1100px){.brand{gap:8px}.brand small{display:none}.header-actions{gap:4px}.header-actions .ui-btn{padding:0 8px}.save-status{display:none}")
C(" .page-list-buttons{flex-wrap:wrap;justify-content:flex-start}\n}",
  " .page-list-buttons{flex-wrap:wrap;justify-content:flex-start}\n"
  " .scope-fonts{grid-template-columns:minmax(0,1fr);gap:4px 0}\n"
  " .scope-fonts>.inspect-button{margin-top:0;justify-self:end}\n"
  " #inspectorTabs [data-inspector-tab] small{font-size:9px;letter-spacing:-.04em}\n"
  "}")
C(".template-grid{grid-template-columns:repeat(4,minmax(0,1fr))}}",
  ".template-grid{grid-template-columns:repeat(4,minmax(0,1fr))}#inspectorTabs [data-inspector-tab]{padding-left:0;padding-right:0}#inspectorTabs [data-inspector-tab] small{font-size:10px;letter-spacing:-.03em}}")
html=html[:a]+css+html[b:]
open(out,'w',encoding='utf-8').write(html)
print('ok',out)
