import asyncio,sys,json
from playwright.async_api import async_playwright
JS="""()=>{const W=innerWidth,H=innerHeight,o=[];
function vis(e){const cs=getComputedStyle(e);return cs.display!='none'&&cs.visibility!='hidden'}
document.querySelectorAll('body *').forEach(e=>{if(e.closest('.rv-stage,.page-list,.thumb-viewport,svg,#templateDialog'))return;const r=e.getBoundingClientRect();if(!r.width||!r.height||!vis(e))return;
 const cs=getComputedStyle(e);let why='';
 if(r.right>W+0.5&&r.left<W)why='offR';
 // clipped by an ancestor
 let p=e.parentElement;while(p&&p!==document.body){const pc=getComputedStyle(p);if(pc.overflowX!='visible'||pc.overflowY!='visible'){const pr=p.getBoundingClientRect();if(pc.overflowX!='visible'&&!/auto|scroll/.test(pc.overflowX)&&(r.right>pr.right+1||r.left<pr.left-1))why+=' clipX:'+(p.id||p.className).toString().slice(0,30);break}p=p.parentElement}
 if(e.children.length==0&&(e.innerText||'').trim()&&cs.textOverflow!='ellipsis'&&e.scrollWidth>e.clientWidth+1&&cs.overflowX!='visible')why+=' textX';
 if((e.tagName=='BUTTON'||e.tagName=='SELECT')&&e.scrollWidth>e.clientWidth+1)why+=' btnX'+e.scrollWidth+'/'+e.clientWidth;
 if(why)o.push([why,e.tagName,e.id,(e.className||'').toString().slice(0,30),Math.round(r.left),Math.round(r.top),Math.round(r.right),Math.round(r.bottom),(e.innerText||'').replace(/\\s+/g,' ').slice(0,24)])});
 return o}"""
async def main(path,w,h,out):
    pw=await async_playwright().start(); b=await pw.chromium.launch(executable_path='/opt/pw-browsers/chromium',args=['--no-sandbox'])
    pg=await b.new_page(viewport={'width':w,'height':h}); errs=[]
    pg.on('pageerror',lambda e:errs.append(str(e)))
    await pg.goto('file://'+path); await pg.wait_for_timeout(3000)
    await pg.keyboard.press('Escape'); await pg.wait_for_timeout(500)
    for t in ['괜찮아요']:
        try: await pg.get_by_text(t).first.click(timeout=1500)
        except: pass
    await pg.wait_for_timeout(800)
    await pg.screenshot(path=out+'.png')
    for x in await pg.evaluate(JS): print(x)
    print('errs',errs); await b.close(); await pw.stop()
asyncio.run(main(sys.argv[1],int(sys.argv[2]),int(sys.argv[3]),sys.argv[4]))
