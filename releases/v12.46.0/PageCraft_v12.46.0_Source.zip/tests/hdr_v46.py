import asyncio,sys
from playwright.async_api import async_playwright
async def main(path):
    pw=await async_playwright().start(); b=await pw.chromium.launch(executable_path='/opt/pw-browsers/chromium',args=['--no-sandbox'])
    pg=await b.new_page(viewport={'width':1400,'height':800})
    await pg.goto('file://'+path); await pg.wait_for_timeout(3000)
    res=[]
    for w in range(1024,1401,16):
        await pg.set_viewport_size({'width':w,'height':800}); await pg.wait_for_timeout(150)
        r=await pg.evaluate("()=>{const h=document.querySelector('.header-actions');let m=0;h.querySelectorAll(':scope>*').forEach(e=>{const r=e.getBoundingClientRect();if(r.width)m=Math.max(m,r.right)});const i=h.querySelector('input').getBoundingClientRect().width;return [Math.round(innerWidth-m),Math.round(i)]}")
        res.append((w,r))
    print(res); await b.close(); await pw.stop()
asyncio.run(main(sys.argv[1]))
